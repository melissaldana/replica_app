# flutter_componentes

Primera aplicación flutter de EduTec

## Pasos para ejecutar el proyecto

Primero vamos a clonar el proyecto
```bash
git clone https://github.com/Willy502/flutter_componentes.git
```

Luego en la carpeta del proyecto vamos a recuperar sus paquetes para poder ejecutar
```bash
flutter packages get
```

Con esto ya podemos ejecutar el proyecto.